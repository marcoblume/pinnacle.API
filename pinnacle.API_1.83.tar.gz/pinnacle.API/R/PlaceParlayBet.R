
#' PlaceParlayBet
#'
#' @param riskAmount numeric Wager amount in  currency
#' @param legslist A list of wagers, where each wager must be in named list format. Required named values are: legBetType, lineId, either team or side, and periodNumber. Optional named values are: altLineId, pitcher1MustStart, or pitcher2MustStart. See the API Manual for more info
#' \itemize{
#' 
#' }
#' @param roundRobinOptions one of the round robin options, default is 'Parlay'
#' \itemize{
#' \item{Parlay}
#' \item{TwoLegRoundRobin}
#' \item{ThreeLegRoundRobin}
#' \item{FourLegRoundRobin}
#' \item{FiveLegRoundRobin}
#' \item{SixLegRoundRobin}
#' \item{SevenLegRoundRobin}
#' \item{EightLegRoundRobin}
#' }
#' @param oddsFormat default:'AMERICAN'
#' \itemize{
#' \item{AMERICAN}
#' \item{DECIMAL}
#' \item{HONGKONG}
#' \item{INDONESIAN}
#' \item{MALAY}
#' }
#' @param acceptBetterLine: Default=TRUE ,boolean Whether or not to accept a bet
#'  when there is a line change in favor of the client
#'
#' @return list containing :
#' \itemize{
#'   \item{status}  If Status is PROCESSED_WITH_ERROR errorCode will be in the response
#'   \item{errorCode}
#' }
#' @export
#'
#' @examples
#' 
#' 

parlaytest <-  list(lineId = 223003280,sportId=33,eventId = 496390430,periodNumber=0,team = 'TEAM1',legBetType = 'Moneyline')
parlaytest2 <- list(lineId = 223001681,sportId=33,eventId = 496392480,periodNumber=0,team = 'TEAM1',legBetType = 'Moneyline')
leglist <- list(parlaytest,parlaytest)

PlaceParlayBet <-
  function(riskAmount,
           legslist = list(list(legBetType = NULL,
                                lineId = NULL,
                                sportId = NULL,
                                eventId = NULL,
                                altLineId = NULL,
                                team = NULL,
                                side = NULL,
                                periodNumber = NULL,
                                pitcher1MustStart = NULL,
                                pitcher2MustStart = NULL)),
           roundRobinOptions = c('Parlay',
                                 'TwoLegRoundRobin',
                                 'ThreeLegRoundRobin',
                                 'FourLegRoundRobin',
                                 'FiveLegRoundRobin',
                                 'SixLegRoundRobin',
                                 'SevenLegRoundRobin',
                                 'EightLegRoundRobin')[1],
           oddsFormat = 'AMERICAN',
           acceptBetterLine = TRUE){
    
    CheckTermsAndConditions()
    
    guids <- c()
    #Generate UUIDs
    for(i in 1:(length(legslist)+1)) {
        Sys.sleep(0.001)
        guids <- c(guids,UUIDgenerate())
    }
    
    place_bet_data <- list(uniqueRequestId=guids[1],
                           acceptBetterLine=acceptBetterLine,
                           oddsFormat=oddsFormat,
                           riskAmount=riskAmount,
                           roundRobinOptions = list(roundRobinOptions),
                           legs = lapply(1:length(legslist),function(leg) c(list(uniqueLegId = guids[-1][leg],legslist[[leg]],pitcher1MustStart=NULL,pitcher2MustStart=NULL))))
    
    place_bet_body <-  rjson::toJSON(place_bet_data)
    
    r <- POST(paste0(.PinnacleAPI$url ,"/v1/bets/parlay"),
              add_headers(Authorization= authorization(),
                          "Content-Type" = "application/json"),
              body = place_bet_body
    )
    fromJSON(content(r,type="text"))
    
  }



